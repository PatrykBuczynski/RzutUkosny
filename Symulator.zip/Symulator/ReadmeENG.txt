Welcome. To import data to the program you need to write them in certain format: "a b c d e"

Where:

a - velocity expressed in m/s
b - mass expressed in kg
c - angel to OX axis expressed in degrees. Value should be in (0, 90) period.
d - gravitacional acceleration, expressed in m/s^2
e - air resistance, expressed in kg/s. Value shouldn't be less than zero.

Please note, that the values must be seperated with spaces.

Example:
20.1 30.4 45 10 10